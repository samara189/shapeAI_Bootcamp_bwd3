import React from "react";

function Note() {
  return (
    <div>
      <h1>Javascript and React.js</h1>
        <p>This was amazing bootcamp taken up by shaury we covered everything
          from scratch including Javascript React.js,HTML
        </p>
        </div>
  );
}

export default Note;