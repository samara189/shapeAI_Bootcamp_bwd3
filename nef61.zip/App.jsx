import React from "react";
import Header from "./Header";
import Footer from "./Footer";
import Note from "./note";

function App() {
  return (
    <div>
      <Header />
      <Footer />
      <Note className="note" />
    </div>
  );
}

export default App;
  
